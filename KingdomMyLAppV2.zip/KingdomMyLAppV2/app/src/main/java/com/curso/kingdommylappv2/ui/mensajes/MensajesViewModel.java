package com.curso.kingdommylappv2.ui.mensajes;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MensajesViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public MensajesViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Esta es la sección de mensajería de la app");
    }

    public LiveData<String> getText() {
        return mText;
    }
}