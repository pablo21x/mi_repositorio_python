package com.curso.kingdommylappv2.ui.mensajes;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.curso.kingdommylappv2.R;
import com.curso.kingdommylappv2.databinding.FragmentMensajesBinding;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MensajesFragment extends Fragment {

    private FragmentMensajesBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        MensajesViewModel mensajesViewModel =
                new ViewModelProvider(this).get(MensajesViewModel.class);

        binding = FragmentMensajesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textMensajes;
        mensajesViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}