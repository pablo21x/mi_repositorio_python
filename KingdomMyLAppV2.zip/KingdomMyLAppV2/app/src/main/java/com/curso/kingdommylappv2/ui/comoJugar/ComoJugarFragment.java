package com.curso.kingdommylappv2.ui.comoJugar;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.curso.kingdommylappv2.databinding.FragmentComoJugarBinding;
import com.curso.kingdommylappv2.ui.datosPersonales.DatosPersonalesViewModel;

public class ComoJugarFragment extends Fragment {

    private @NonNull FragmentComoJugarBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ComoJugarViewModel comoJugarViewModel =
                new ViewModelProvider(this).get(ComoJugarViewModel.class);

        binding = FragmentComoJugarBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textComoJugar;
        comoJugarViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}