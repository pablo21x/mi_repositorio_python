package com.curso.kingdommylappv2.ui.infoMyL;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.curso.kingdommylappv2.databinding.FragmentInfoMylBinding;

public class InfoMyLFragment extends Fragment {

    private FragmentInfoMylBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        InfoMyLViewModel infoMyLViewModel =
                new ViewModelProvider(this).get(InfoMyLViewModel.class);

        binding = FragmentInfoMylBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textInfoMyL;
        infoMyLViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}