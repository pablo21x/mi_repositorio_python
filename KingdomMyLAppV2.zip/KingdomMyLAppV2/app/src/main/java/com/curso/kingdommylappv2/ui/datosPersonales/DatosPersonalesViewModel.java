package com.curso.kingdommylappv2.ui.datosPersonales;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class DatosPersonalesViewModel extends ViewModel {
    private final MutableLiveData<String> mText;

    public DatosPersonalesViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Esto es la seccion de datos personales del usuario");
    }

    public LiveData<String> getText() {
        return mText;
    }
}