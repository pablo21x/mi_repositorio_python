package com.curso.kingdommylappv2.ui.comoJugar;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

public class ComoJugarViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public ComoJugarViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Esto es la seccion de instrucciones de como jugar");
    }

    public LiveData<String> getText() {
        return mText;
    }
}